#include <linux/init.h>
#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/netfilter.h>
#include <linux/netfilter_ipv4.h>
#include <linux/ip.h>
#include <linux/tcp.h>

/*
 * @source by: https://kel.bz/post/netfilter/
 * transform byte ip address to xxx.xxx.xxx.xxx type
 */
#define NIPQUAD(addr) \
    ((unsigned char *)&addr)[0], \
    ((unsigned char *)&addr)[1], \
    ((unsigned char *)&addr)[2], \
    ((unsigned char *)&addr)[3]

static int my_open(struct inode *inode, struct file *file);
static ssize_t my_read(struct file *file, char __user *user_buffer, size_t count, loff_t *ppos);

static const struct file_operations myproc_fops = {
    .owner = THIS_MODULE,
    .open = my_open,
    .read = my_read,
};

static int my_open(struct inode *inode, struct file *file)
{
    printk(KERN_INFO "===== MODULE OPENED =====\n");
    return 0;
}

static ssize_t my_read(struct file *file, char __user *user_buffer, size_t count, loff_t *ppos)
{
    return 0;   
}

/*
 * IP string to ip address.
 */
unsigned int inet_addr(char *str)
{
    int a, b, c, d;
    char arr[4];
    sscanf(str, "%d.%d.%d.%d", &a, &b, &c, &d);
    arr[0] = a; arr[1] = b; arr[2] = c; arr[3] = d;
    return *(unsigned int *)arr;
}

/*
 * change header of packet to forward to specified port number.
 */ 
unsigned int pkt_changing(void* priv, struct sk_buff *skb, const struct nf_hook_state *state)
{
    struct iphdr *iph = ip_hdr(skb);
    struct tcphdr *tcph = tcp_hdr(skb);
    unsigned int sport;

    if (!skb) return NF_ACCEPT;

    iph = ip_hdr(skb);
    tcph = tcp_hdr(skb);

    // ntohs is for tr wansforming network byte stream to host byte stream
    printk(KERN_INFO "PRE_ROUTING packet(%u; %d; %d; %d.%d.%d.%d; %d.%d.%d.%d)\n",
        iph->protocol,
        ntohs(tcph->source),
        ntohs(tcph->dest),
        NIPQUAD(iph->saddr),
        NIPQUAD(iph->daddr));

    // change sport number and dport number to 7777
    // if source port number is 33333.
    sport = ntohs(tcph->source);
    if (sport == 33333) {
        tcph->source = htons(7777);
        tcph->dest = htons(7777);
        iph->daddr = inet_addr("10.37.129.5");
        printk(KERN_INFO "[After changing]: %d %d", ntohs(tcph->source), ntohs(tcph->dest));
    }

    return NF_ACCEPT;   // let the packet go through the rest of process.
}

unsigned int pkt_monitoring(void* priv, struct sk_buff *skb, const struct nf_hook_state *state)
{
    struct iphdr *iph;
    struct tcphdr *tcph;
    
    if (!skb) return NF_ACCEPT;

    iph = ip_hdr(skb);
    tcph = tcp_hdr(skb);

    if (state->hook == 2) {  // NF_INET_FORWARD
        printk(KERN_INFO "FORWARD packet(%u; %d; %d; %d.%d.%d.%d; %d.%d.%d.%d)\n",
            iph->protocol,
            ntohs(tcph->source),
            ntohs(tcph->dest),
            NIPQUAD(iph->saddr),
            NIPQUAD(iph->daddr));
    } else if (state->hook == 4) {   // NF_INET_POST_ROUTING
        printk(KERN_INFO "POST_ROUTING packet(%u; %d; %d; %d.%d.%d.%d; %d.%d.%d.%d)\n",
            iph->protocol,
            ntohs(tcph->source),
            ntohs(tcph->dest),
            NIPQUAD(iph->saddr),
            NIPQUAD(iph->daddr));
    }

    return NF_ACCEPT;
}

/*
 * All of these 3 struct is for providing information about hooking
 * whice includes hooking callback function, protocol family, hooking point,
 * and priority.
 */
static struct nf_hook_ops pkt_changing_hook = {
    .hooknum = NF_INET_PRE_ROUTING,
    .pf = PF_INET,
    .hook = &pkt_changing,
    .priority = NF_IP_PRI_FIRST,
};

static struct nf_hook_ops pkt_forwarding_hook = {
    .hooknum = NF_INET_FORWARD,
    .pf = PF_INET,
    .hook = &pkt_monitoring,
    .priority = NF_IP_PRI_FIRST,
};

static struct nf_hook_ops pkt_output_hook = {
    .hooknum = NF_INET_POST_ROUTING,
    .pf = PF_INET,
    .hook = &pkt_monitoring,
    .priority = NF_IP_PRI_FIRST,
};

static int __init simple_init(void) {
    printk(KERN_INFO "===== MODULE INIT =====\n");

    // register my hook functions
    nf_register_hook(&pkt_changing_hook);
    nf_register_hook(&pkt_forwarding_hook);
    nf_register_hook(&pkt_output_hook);

    return 0;
}

static void __exit simple_exit(void) {
    printk(KERN_INFO "===== MODULE EXIT ====\n");
    // unregister my hook functions
    nf_unregister_hook(&pkt_changing_hook);
    nf_unregister_hook(&pkt_forwarding_hook);
    nf_unregister_hook(&pkt_output_hook);

    printk(KERN_INFO ">>>>> myproc is deleted <<<<<\n");

    return;
}

module_init(simple_init);
module_exit(simple_exit);

MODULE_AUTHOR("Yoon Han, Minsub Kim");
MODULE_DESCRIPTION("Kernel module to forward packet and monitor");
MODULE_LICENSE("GPL");
MODULE_VERSION("0.1");