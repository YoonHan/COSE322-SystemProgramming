/*
 * @author: 김 민섭, 한 윤
 */
#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/proc_fs.h>
#include <linux/init.h>
#include <asm/uaccess.h>

#define PROC_DIRNAME "myproc"
#define PROC_FILENAME "myproc"
#define BUFFER_MAX_LEN 2000

static struct proc_dir_entry *proc_dir;
static struct proc_dir_entry *proc_file;

extern long write_t_s[BUFFER_MAX_LEN];
extern long write_t_us[BUFFER_MAX_LEN];
extern long write_t_s_nilfs2[BUFFER_MAX_LEN];
extern long write_t_us_nilfs2[BUFFER_MAX_LEN];
extern unsigned long long block_n[BUFFER_MAX_LEN];
extern unsigned long long block_n_nilfs2[BUFFER_MAX_LEN];
extern unsigned int pos;
extern unsigned int pos_nilfs2;
extern const char *fs[BUFFER_MAX_LEN];
extern const char *fs_nilfs2[BUFFER_MAX_LEN];
unsigned int i;
unsigned int i_nilfs2;

static int my_open(struct inode *inode, struct file *file)
{
    printk(KERN_INFO "MODULE OPENED!!\n");

    return 0;
}

static ssize_t my_read(struct file *file, char __user *user_buffer, size_t count, loff_t *ppos)
{
    /*
     * read log in buffer
     */
    printk("Write Time, Block No, Filesystem Type");

    // because this is implemented by circular structure,
    // start the loop with the position + 1
    // and end with position - 1.
    // first while loop is for ext4 FS
    // second while loop is for nilfs2 FS.
    i = pos + 1;
    i_nilfs2 = pos_nilfs2 + 1;
    while (i != pos)
    {
        if (i >= BUFFER_MAX_LEN)
            i = 0;
        printk(KERN_INFO "[%d]%ld.%ld, %Lu, %s",
               i,
               write_t_s[i],
               write_t_us[i],
               block_n[i],
               fs[i]);
        i++;
    }

    while (i_nilfs2 != pos_nilfs2)
    {
        if (i_nilfs2 >= BUFFER_MAX_LEN)
            i_nilfs2 = 0;
        printk(KERN_INFO "[%d]%ld.%ld, %Lu, %s",
               i_nilfs2,
               write_t_s_nilfs2[i_nilfs2],
               write_t_us_nilfs2[i_nilfs2],
               block_n_nilfs2[i_nilfs2],
               fs_nilfs2[i_nilfs2]);
        i_nilfs2++;
    }

    return 0;
}

static ssize_t my_write(struct file *file, const char __user *user_buffer, size_t count, loff_t *ppos)
{
    /*
     * clear log in buffer
     */
    char kernel_buffer[10];
    memcpy(kernel_buffer, user_buffer, 5);

    printk(KERN_INFO "MODULE WRITTEN!!\n");

    if (strcmp(kernel_buffer, "clear"))
    {
        // reinitialise all the variables
    }

    return count;
}

static const struct file_operations myproc_fops = {
    .owner = THIS_MODULE,
    .open = my_open,
    .read = my_read,
    .write = my_write,
};

static int __init simple_init(void)
{
    printk(KERN_INFO "MODULE INIT!!\n");

    proc_dir = proc_mkdir(PROC_DIRNAME, NULL);
    proc_file = proc_create(PROC_FILENAME, 0600, proc_dir, &myproc_fops);

    return 0;
}

static void __exit simple_exit(void)
{
    printk(KERN_INFO "MODULE EXIT!!\n");
    remove_proc_entry(PROC_FILENAME, proc_dir);
    remove_proc_entry(PROC_DIRNAME, NULL);
    printk(KERN_INFO "myproc deleted!!\n");
    return;
}

module_init(simple_init);
module_exit(simple_exit);

MODULE_AUTHOR("Yoon Han, Minsub Kim");
MODULE_DESCRIPTION("Kernel module for disk block logging");
MODULE_LICENSE("GPL");
MODULE_VERSION("0.1");