/*
 * @author: 한 윤, 김 민섭
 * @date: 2019. 11. 06
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <pthread.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <time.h>
#include <sys/time.h>
#include <math.h> // for flooring float number.

#define NUM_OF_PTHRDS 5
#define MAX_RECV_SIZE 65535

// print 50 "=" character on console.
void print_divider()
{
    printf("==================================================\n");
    return;
}

// get "h:m:s.ms" format time string.
void get_time_str(char *time_str, int len)
{
    time_t t;
    struct tm *tm;
    struct timeval tv;
    int ms_int;
    char ms_str[3];

    gettimeofday(&tv, NULL);
    ms_int = lrint(tv.tv_usec / 1000.0);
    tm = localtime(&tv.tv_sec);

    strftime(time_str, len, "%H:%M:%S", tm);
    sprintf(ms_str, "%d", ms_int);
    strcat(time_str, ".");
    strcat(time_str, ms_str);

    return;
}

// pthread routine
void *packet_receive(void *data)
{
    pthread_t t_id = pthread_self(); // point to opened pthread id
    struct sockaddr_in server_addr;
    char buff[MAX_RECV_SIZE + 1];              // received message buffer
    unsigned int recv_cnt = 0;                 // the # of receiving count from server
    unsigned int port = *(unsigned int *)data; // connected port number
    unsigned int msg_lngth;                    // received message length
    char msg_lngth_str[10];
    FILE *fp;                          // .txt file pointer
    char filename[10];                 // .txt file name
    char time_str[15];                 // h:m:s.ms string
    char log_msg[MAX_RECV_SIZE + 100]; // log message buffer

    // create socket
    int socket_fd;
    if ((socket_fd = socket(PF_INET, SOCK_STREAM, 0)) == -1)
    {
        printf("(TID: %ld) socket creation failed\n", t_id);
        exit(1);
    }

    // connect socket
    memset(&server_addr, 0, sizeof(server_addr));
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(port);
    server_addr.sin_addr.s_addr = inet_addr("10.37.129.4");

    if (connect(socket_fd, (struct sockaddr *)&server_addr, sizeof(server_addr)) == -1)
    {
        printf("(TID: %ld) socket connection failed. (port #%u)\n", t_id, port);
        exit(1);
    }
    else
    {
        printf("(TID: %ld) socket connection success. (port #%u)\n", t_id, port);
    }

    // open file with append mode
    sprintf(filename, "%d", port);
    strcat(filename, ".txt");
    if ((fp = fopen(filename, "wa")) == NULL)
    {
        printf("(port #%u) file cannot be opened.\n", port);
        exit(1);
    }

    // receive packets from server
    // AND log them into .txt files.
    while (recv_cnt < 50)
    {
        // flush array at every iteration
        memset(buff, 0, sizeof(buff));
        memset(log_msg, 0, sizeof(log_msg));

        msg_lngth = recv(socket_fd, buff, MAX_RECV_SIZE, 0);
        get_time_str(time_str, sizeof(time_str));
        sprintf(msg_lngth_str, "%u", msg_lngth);

        strcat(log_msg, time_str); // h:m:s.ms
        strcat(log_msg, " ");
        strcat(log_msg, msg_lngth_str); // h:m:s.ms <msg_length>
        strcat(log_msg, " ");
        strcat(log_msg, buff); // h:m:s.ms <msg_length> <msg>

        printf("%s\n", log_msg);
        fputs(log_msg, fp);
        fputs("\n", fp);
        recv_cnt++;
    }

    printf("(TID: %ld) closed. \n", t_id);
    close(socket_fd);
    fclose(fp);
    return data;
}

int main(int argc, char *argv[])
{
    pthread_t thread[NUM_OF_PTHRDS];
    int ports[NUM_OF_PTHRDS];
    int i;

    // store port values into array
    for (i = 0; i < NUM_OF_PTHRDS; i++)
    {
        printf("enter socket #%d port number: ", i + 1);
        scanf("%d", &ports[i]);
    }
    print_divider();

    // create pthreads
    for (i = 0; i < NUM_OF_PTHRDS; i++)
    {
        if (pthread_create(&thread[i], NULL, packet_receive, (void *)&ports[i]) == 0)
        {
            printf("pthread %d is created\n", i + 1);
        }
    }

    // wait pthreads
    printf("Waiting for all the pthreads done\n");
    print_divider();
    for (i = 0; i < NUM_OF_PTHRDS; i++)
    {
        pthread_join(thread[i], NULL);
    }

    print_divider();
    printf("%s", "All the packets were received completely\n");
    printf("AND all logs were stored in each of .txt files individually.\n");

    return 0;
}